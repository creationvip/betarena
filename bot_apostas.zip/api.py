import requests
from config import API_KEY, BASE_URL

headers = {"x-apisports-key": API_KEY}

def jogos_do_dia(data):
    url = f"{BASE_URL}/fixtures?date={data}"
    r = requests.get(url, headers=headers)
    return r.json().get("response", [])
