def estimar_probabilidades(media_gols, btts_percent):
    return {
        "over15": min(media_gols / 2, 0.95),
        "btts": btts_percent / 100
    }
