def gerar_bilhete(apostas):
    apostas = sorted(apostas, key=lambda x: x["value"], reverse=True)
    return apostas[:2]
