def calcular_value(prob, odd):
    return (prob * odd) - 1
