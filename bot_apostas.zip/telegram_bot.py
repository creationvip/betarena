from telegram import Bot

bot = Bot(token="SEU_TOKEN_TELEGRAM")

def enviar_bilhete(chat_id, bilhete):
    msg = "🎟️ BILHETE DO DIA\n\n"
    for a in bilhete:
        msg += f"⚽ {a['jogo']}\n🎯 {a['mercado']}\n💰 Odd: {a['odd']}\n\n"
    bot.send_message(chat_id=chat_id, text=msg)
