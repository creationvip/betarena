from analise import estimar_probabilidades
from value import calcular_value
from bilhete import gerar_bilhete

apostas = [
    {"jogo": "Time A x Time B", "mercado": "BTTS", "odd": 1.82, "value": calcular_value(0.7, 1.82)},
    {"jogo": "Time C x Time D", "mercado": "Over 1.5", "odd": 1.75, "value": calcular_value(0.75, 1.75)}
]

bilhete = gerar_bilhete(apostas)
print(bilhete)
